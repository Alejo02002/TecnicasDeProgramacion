
package adivinaelnumero;

import java.util.Scanner;


public class AdivinaElNumero {

    
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        char a;
        int validos=0;
        int[] numeroelegido = new int[3];
        int[] numganador = new int[3];
        int elegido; 
        boolean gano = false;
        // Obtenemos el numero que hay que adivinar
        int n = generarNumero(100, 999);
        
        // lo cargamos al arreglo de enteros
        numganador[2] = (n / 1) % 10;
        numganador[1] = (n / 10) % 10;
        numganador[0] = (n / 100) % 10;
    
    //    listarNumero(numganador);
        System.out.println("");

        //Arrancamos el Juego
        
        do {

            System.out.println("Averigua cual es el numero secreto!!");
            System.out.println("Tienes 10 intentos!");

            for (int i = 0; i < 10; i++) {
                //pedimos los números al jugador
                System.out.print("Intento N " + (i + 1) + ": ");
                elegido = sc.nextInt();
                // lo guardamos en el arreglo de enteros
                numeroelegido[2] = (elegido / 1) % 10;
                numeroelegido[1] = (elegido / 10) % 10;
                numeroelegido[0] = (elegido / 100) % 10;
                // Lo mandamos a validar para saber cuantos aciertos tiene
                listarNumero(numeroelegido);
                validos = validarNumero(numeroelegido, numganador);
                if (validos == 3) {
                    System.out.println("Usted es el GANADOR!!");
                    gano = true;
                    break;
                } else {
                    System.out.println("Usted tuvo " + validos + " aciertos!");
                    validos = 0;
                }
               
            }
            if (!gano) {
                System.out.println("PERDISTE");
            }

            
            System.out.println("Para seguir jugando presione s o S");
            String opc = sc.next();
            a = opc.charAt(0);

        } while (a == 'S' || a == 's');

    }

    static int generarNumero(int max, int min) {
        int cota = (max - min) - 1;
        int num = (int) (Math.random() * cota) + min;
        return num;
    }

    static int validarNumero(int[] nelegido, int[] nganador) {
        int aciertos = 0;
        for (int i = 0; i < nganador.length; i++) {
            for (int j = 0; j < nelegido.length; j++) {
                if (nelegido[i] == nganador[j]) {
                    aciertos++;
                }
            }
        }
        return aciertos;
    }
    
    static void listarNumero(int[] arr){
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    
    }

    
    
}
