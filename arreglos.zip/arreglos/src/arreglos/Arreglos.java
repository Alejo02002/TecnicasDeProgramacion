package arreglos;

public class Arreglos {

    public static void main(String[] args) {
     
        int [] listanumerica = {10,20,50,-10};
        System.out.println("el tamanio del arreglo es: " + listanumerica.length);
        System.out.println("el dato en la pos 3 es: " + listanumerica[3]);
      
        for (int i = 0; i < listanumerica.length; i++) {
            System.out.println("El dato en el indice " + i + " es: " + listanumerica[i]);
        }
        
        System.out.println("-----------------------------------------------");
        System.out.println("");
      
     // tipo dato    nombre       instancia    
        String [] listaDeNombres = new String[5];
        
        listaDeNombres[0] = "Sergio";
        listaDeNombres[1] = "Pepe";
        listaDeNombres[2] = "Pancho";
        listaDeNombres[3] = "Lore";
        listaDeNombres[4] = "Coco";
        
        for (int i = 0; i < listaDeNombres.length; i++) {
            System.out.println("Nombre en la pos " + i + " :" + listaDeNombres[i]);
        }
        
    }
    
}
