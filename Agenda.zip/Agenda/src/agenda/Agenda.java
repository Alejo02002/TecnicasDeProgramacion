
package agenda;

import java.util.Scanner;

public class Agenda {

    public static void main(String[] args) {

    // Agenda telefonica marca Acme
    /*
      1- Agragar Contactos
      2- Listar Contactos
      3- Buscar Contacto
      4- Salir
    Ingrese su opcion:_
    
    */
    

    Scanner sc = new Scanner(System.in); 
    String [] nombreContacto;
    int [] numerosTelefono;
    String nombre;
    int nrotel;
    int tam;   
        
        System.out.println("Agenda Marca Acme");
        System.out.print("Ingrese la cantidad de Contactos a ingresar: ");
        tam = sc.nextInt();
       
        nombreContacto = new String[tam];
        numerosTelefono = new int[tam];
        
        for (int i = 0; i < tam; i++) {
            // Guardo el nombre del contacto
            System.out.print("Ingrese el nombre del contacto " + i + ":");
            nombre = sc.next();
            nombreContacto[i] = nombre;
            
            //guardo el numero de tel.
            
            System.out.print("Ahora ingrese el numero de telefono:");
            nrotel = sc.nextInt();
            numerosTelefono[i] = nrotel;
                        
        }
        
        
        // Mostrar Agenda cargada
        
        System.out.println("****************  Agenda Marca Acme   *******************");
        System.out.println("Listado de Contactos");
        for (int i = 0; i < tam; i++) {
            System.out.println("Nro.: " + i);
            System.out.println("Nombre: " + nombreContacto[i]);
            System.out.println("Tel.: " + numerosTelefono[i]);
            System.out.println("");
            System.out.println("-----------------------");
        }
        
    }
    
}
