package loteria;

import java.util.Scanner;

public class Loteria {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] carton = new int[6];
        int[] loteria = new int[6];
        int aciertos = 0;
        char opc;
        do {

            // Cargamos el carton del jugador
            for (int i = 0; i < carton.length; i++) {
                System.out.print("Ingrese el numero " + (i + 1) + ":");
                int n = sc.nextInt();
                if (n >= 1 && n <= 49) {
                    if (!esRepetido(carton, i, n)) {
                        carton[i] = n;
                    } else {
                        System.out.println("El numero ingresado esta repetido");
                        i--;
                    }
                } else {
                    System.out.println("El numero ingresado esta fuera de rango (Debe ser entre 1 y 49)");
                    i--;
                }
            }
            System.out.println("El Carton del jugador es:");
            listarCarton(carton);
            System.out.println("");

            // Generamos el sorteo de la loteria
            for (int i = 0; i < loteria.length; i++) {
                int num = generarNumero(1, 49);
                if (!esRepetido(loteria, i, num)) {   // if(a=>b)
                    loteria[i] = num;
                } else {
                    i--;
                }
            }
                      
            System.out.println("Sorteo de Loteria:");
            listarCarton(loteria);
            System.out.println("");
            // fin del sorteo

            // Mostrar los resultados
            aciertos = 0;
            for (int i = 0; i < carton.length; i++) {
                if (esRepetido(loteria, carton.length - 1, carton[i])) {
                    aciertos++;
                }
            }
            System.out.println("Se han encontrado " + aciertos + " aciertos");

            System.out.println("");
            System.out.println("");

            System.out.println("Se han encontrado " + controlarAciertos(carton, loteria) + " aciertos");
            System.out.println("");
            System.out.println("");

            System.out.println("Para volver a jugar presione S ");
            String op = sc.next();
            opc = (char) op.charAt(0);
            limpiarConsola();
        } while (opc == 's' || opc == 'S');

    }

    static boolean esRepetido(int[] carton, int tam, int numeroIngresado) {
        boolean ok = false;
        for (int i = 0; i <= tam; i++) {
            if (numeroIngresado == carton[i]) {
                ok = true;
           }
        }
       return ok;
      
    }

    static void listarCarton(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + "-");
        }
    }

    static int generarNumero(int max, int min) {
        int cota = (max - min) - 1;
        int num = (int) (Math.random() * cota) + min;
        return num;
    }

    static int controlarAciertos(int[] carton, int[] sorteo) {
        int c = 0;
        for (int i = 0; i < carton.length; i++) {
            for (int j = 0; j < sorteo.length; j++) {
                if (carton[i] == sorteo[j]) {
                    c = +1;
                }
            }
        }
        return c;

    }

    static void limpiarConsola() {
        for (int i = 0; i < 25; i++) {
            System.out.println("");
        }
    }

}
