package matrix_24102022;

import java.util.Scanner;

public class Matrix_24102022 {

    public static void main(String[] args) {

        /*
        Dada una Matriz de n x n, dibujar el marco con Xs. 
        xxxxxxxx
        x      x
        x      x
        xxxxxxxx   
    
         */
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el tamanio de la Matriz: ");
        int n = sc.nextInt();

        char[][] Matrix = new char[n][n];

        for (int i = 0; i < Matrix.length; i++) {
            for (int j = 0; j < Matrix.length; j++) {
                Matrix[i][j] = ' ';

                if (i == 0 || i == Matrix.length - 1) {
                    Matrix[i][j] = 'X';
                }
                if (j == 0 || j == Matrix.length - 1) {
                    Matrix[i][j] = 'X';
                }

            }

        }

        ListarMatrix(Matrix);

    }

    static void ListarMatrix(char[][] m) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m.length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }

    }

}
