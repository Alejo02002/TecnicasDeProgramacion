package randomfuncion;

public class RandomFuncion {

    public static void main(String[] args) {
      
       int numeroAleatorio = GenerarNumeroAleatorio(25, 30);
       System.out.println("El número aleatorio entre 25 y 30 es: " + numeroAleatorio);
    }  
    // Gente, les paso la Función para obtener números aleatorios;
    // Le pasamos como parámetros la cota de números (el minimo y maximo)de donde 
    // queremos obtener los números (incluye los extremos)
    
    static int GenerarNumeroAleatorio(int min,int max){
    int cota = (max - min) + 1;     
    return (int)(Math.random() * cota) + min;
    }
    
}
