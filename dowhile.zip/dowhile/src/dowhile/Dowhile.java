
package dowhile;

import java.util.Scanner;


public class Dowhile {

    public static void main(String[] args) {
        
         // declaracion de variables
        Scanner teclado = new Scanner(System.in);
        int opc;
        double sup_tri;
        double base, altura;
        // fin de declaracion de variables
        
        do {
            System.out.println("**************   CALCULADOR DE SUPERFICIES  **************");
            System.out.println("");
            System.out.println("");
            System.out.println("");

            System.out.println("1 - TRIANGULO");
            System.out.println("2 - CUADRADO");
            System.out.println("3 - CIRCULO");
            System.out.println("4 - Salir");
            System.out.println("");
            System.out.print("Ingrese su opcion: ");
            opc = teclado.nextInt();

            switch (opc) {
                case 1:
                    System.out.println("*******  CALCULADOR DE SUP. DE UN TRIANGULO  *****************");
                    System.out.println("");
                    System.out.println("Ingrese la BASE: ");
                    base = teclado.nextDouble();
                    System.out.println("Ingrese la ALTURA: ");
                    altura = teclado.nextDouble();
                    sup_tri = (base * altura) / 2;
                    System.out.println("La Sup. de su Triangulo es: " + sup_tri);

                    break;

                case 2:
                    System.out.println("*****   CALCULADOR DE SUP. DE UN CUADRADO  *******************");
                    break;

                case 3:
                    System.out.println("*****   CALCULADOR DE SUP. DE UN CIRCULO   ********************");
                    break;

                default:
                    System.out.println("Saliendo del sistema");
                    break;
            }
                        
        } while (opc != 4);

        
    }
    
}
